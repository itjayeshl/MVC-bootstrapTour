﻿var timeout = 5000;
var _ObjFormDetails = "";
var _globalFormId = "";
var _current_user = null;
//Global Message
var showglobalmessage = function (Message, MessageType, Header) {
    if (MessageType == '' || MessageType == undefined || MessageType == null) {
        MessageType = "error";
    }
    if (Header == '' || Header == undefined || Header == null) {
        Header = "Message";
    }
    MessageType = MessageType.toLocaleLowerCase();
    if (Message != '' && Message != undefined && Message != null) {
        $.gritter.add({
            title: Header,
            class_name: MessageType,
            text: Message,
            sticky: false,
            after_open: function () {
            }
        });
    }
}

//waiting
var showwaiting = function (object) {
    if (object == null || object == undefined) {
        object = $('#page-wrapper');
    }
    console.log(object);
    var timeid = (((new Date()).getTime() * 10000) + 621355968000000000);
    $(object).block({
        message: '<div class="circleloading" id="circleloading_' + timeid + '"></div>',
        css: { backgroundColor: 'none', border: 'none', cursor: 'default' },
        overlayCSS: {
            backgroundColor: '#ececec',
            opacity: '0.35',
            cursor: 'default'
        },
        onBlock: function () {
            if ($('.blockUI.blockMsg.blockElement').find('.MainDiscussiondiv').length == 0 && $('.blockUI.blockMsg.blockElement').find('#iFrameDocumentPreview').length == 0 && $('.blockUI.blockMsg.blockElement').find('.MainFileDocumentdiv').length == 0 && $('.blockUI.blockMsg.blockElement').find('.PopoverChangeCategories').length == 0) {
                $('.circleloading').css('background-image', $('.circleloading').css('background-image'));
                if ($('#circleloading_' + timeid).parent().parent().height() < 100) {
                    $('#circleloading_' + timeid).css('background-repeat', 'no-repeat');
                    $('#circleloading_' + timeid).css('height', '20px');
                    $('#circleloading_' + timeid).css('margin', '10px auto');
                    $('#circleloading_' + timeid).css('background-size', '33px auto');
                }
                $('.blockOverlay').css('height', $(object)[0].scrollHeight);
                if ($(object).hasClass('MasterParentDiv')) {
                    if ($('.blockUI.blockOverlay').height() > 500) {
                        $('.blockUI.blockMsg.blockElement').css('top', ($(object)[0].scrollTop + 200) + 'px');
                        $(object).scroll(function () { $('.circleloading').parent().css('top', ($(object)[0].scrollTop + 200) + 'px'); });
                    }
                }
            }
        }
    });
    $('.blockOverlay').attr('title', 'Please Wait');
}

var hidewaiting = function (object) {
    if (object == null || object == undefined) {
        object = $('#page-wrapper');
    }
    $(object).unblock();
    $(object).off("scroll");

}

// Loading
var showloading = function (object, msg) {
    //alert(1);
    if (object == null || object == undefined || object.trim() == "") {
        object = $('#page-wrapper');
    }
    if (msg == null || msg == undefined || msg.trim() == "") {
        msg = "Processing";
    }
    $(object).block({
        message: '<h5>' + msg + '</h5>' +
                 '<img src="/Content/images/bx_loader.gif" alt=""></img>',
        css: {
            border: 'none',
            background: 'rgba(255, 255, 255, 0.90)',
            //  top: 200
        },
    });
}
var hideloading = function (object) {
    if (object == null || object == undefined || object.trim() == "") {
        object = $('#page-wrapper');
    }
    $(object).unblock();
}


var getFilePath = function () {
    return window.location.origin +'/';
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

//Show Progress...
function showProgress(button) {
    $(button).find('i').not('.fa-spinner').hide();
    $(button).addClass('disabled').find('.fa-spinner').removeClass('hidden');
}

function hideProgress(button) {
    $(button).find('i').not('.fa-spinner').show();
    $(button).removeClass('disabled').find('.fa-spinner').addClass('hidden');
}

// Get Parameters Values.....
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}
//Email Validation Function

function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};
var specialKeys = new Array();
specialKeys.push(8); //Backspace
function IsNumeric(e) {
    var keyCode = e.which ? e.which : e.keyCode
    var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
    document.getElementById("error").style.display = ret ? "none" : "inline";
    return ret;
}