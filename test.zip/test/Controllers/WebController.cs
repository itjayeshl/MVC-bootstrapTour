﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using test.Models;

namespace test.Controllers
{
    public class WebController : Controller
    {
        // GET: Web
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddUserProfile(ClientModel objProject)
        {
            ApiResult result = new ApiResult();
            TempTestEntities db = new TempTestEntities();
            try
            {
                Thread.Sleep(10000);
                //var email_check = db.addusers.Where(c => c.email == objProject.email).Count();
                result.data = "testing";
                result.success = true;
                result.title = "Client";
                result.message = "Email Already Exist";
                //if (email_check != 0)
                //{

                //    result.data = email_check;
                //    result.success = false;
                //    result.title = "Client";
                //    result.message = "Email Already Exist";

                //}
                //else
                //{
                //    result.data = objProject.addClient(objProject);
                //    result.success = true;
                //}
            }
            catch (Exception e)
            {
                result.success = false;
                result.title = "Client";
                result.message = e.Message.ToString();
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}