﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test.Models
{
    public class ClientModel
    {
        public decimal id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string lname { get; set; }
        public string contact { get; set; }

        public ClientModel addClient(ClientModel objClient)
        {
            TempTestEntities db = new TempTestEntities();
            try
            {


                adduser client = new adduser();
                // project.id = objProject.id;
                client.fname = objClient.name;
                client.email = objClient.email;
                client.lname = objClient.lname;
                client.contact = objClient.contact;


                db.addusers.Add(client);
                db.SaveChanges();

                objClient.id = client.id;
             
           
                return this;
            }
            catch (Exception e)
            {

                throw e;
            }
        }
    }
}